/**
 * Single redirect point – only stored, pre-validated URLs are used.
 * Never use with raw input from request params/query/body!
 * @param {import('fastify').FastifyReply} reply
 * @param {string} code
 * @param {{store: Map}} options
 */
function redirectByCode(reply, code, { store }) {
  const entry = store.get(code);
  if (!entry || typeof entry.target_url !== 'string') {
    // Do not leak info about existence
    return reply.code(404).send({ error: 'Not found' });
  }
  const url = entry.target_url;
  // Defensive: Only allow absolute http/https URLs, no CR/LF, no fragments
  if (!/^https?:\/\//.test(url)) {
    return reply.code(400).send({ error: 'Invalid redirect target' });
  }
  if (/\r|\n/.test(url)) {
    return reply.code(400).send({ error: 'Invalid redirect target' });
  }
  if (url.includes('#')) {
    return reply.code(400).send({ error: 'Invalid redirect target' });
  }
  entry.hits++;
  return reply.redirect(url, 302);
}

module.exports = { redirectByCode };
