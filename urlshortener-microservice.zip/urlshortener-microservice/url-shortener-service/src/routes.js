const { nanoid } = require('nanoid');
const { z } = require('zod');
const { redirectByCode } = require('./security/redirectByCode');
const net = require('net');

const DANGEROUS_SCHEMES = ['javascript:', 'data:', 'vbscript:'];

function isPrivateIp(host) {
  if (net.isIP(host) === 4) {
    const parts = host.split('.').map(Number);
    if (parts[0] === 10) return true;
    if (parts[0] === 127) return true;
    if (parts[0] === 192 && parts[1] === 168) return true;
    if (parts[0] === 172 && parts[1] >= 16 && parts[1] <= 31) return true;
    return false;
  }
  if (net.isIP(host) === 6) {
    if (host === '::1' || host.startsWith('fd') || host.startsWith('fe80')) return true;
    return false;
  }
  return false;
}

function normalizeUrl(input, { allowedHosts, blockPrivateNetworks }) {
  let url;
  try {
    url = new URL(input);
  } catch {
    return { error: 'Invalid URL' };
  }
  const proto = url.protocol.toLowerCase();
  if (!['http:', 'https:'].includes(proto)) return { error: 'Invalid URL' };
  if (DANGEROUS_SCHEMES.includes(proto)) return { error: 'Invalid URL' };
  const host = url.hostname.toLowerCase();
  if (host === 'localhost') return { error: 'Domain not allowed' };
  if (blockPrivateNetworks && isPrivateIp(host)) return { error: 'Domain not allowed' };
  if (allowedHosts && !allowedHosts.includes(host)) return { error: 'Domain not allowed' };
  url.hash = '';
  url.protocol = proto;
  url.hostname = host;
  if ((url.protocol === 'http:' && url.port === '80') || (url.protocol === 'https:' && url.port === '443')) url.port = '';
  const normalized = url.toString();
  if (/\r|\n/.test(normalized)) return { error: 'Invalid URL' };
  return { url: normalized };
}

module.exports = async function routes(app) {
  if (!app.store) app.store = new Map();
  const store = app.store;
  const env = app.config || process.env;
  const ALLOWED_HOSTS = (env.ALLOWED_HOSTS)
    ? env.ALLOWED_HOSTS.split(',').map(h => h.trim().toLowerCase()).filter(Boolean)
    : null;
  const BLOCK_PRIVATE_NETWORKS = (typeof env.BLOCK_PRIVATE_NETWORKS !== 'undefined')
    ? env.BLOCK_PRIVATE_NETWORKS !== 'false'
    : true;
  const shortenSchema = z.object({ url: z.string().url() });

  app.get('/healthz', {
    schema: {
      response: {
        200: {
          type: 'object',
          properties: { status: { type: 'string' } }
        }
      }
    }
  }, async () => ({ status: 'ok' }));

  app.post('/shorten', {
    schema: {
      body: {
        type: 'object',
        required: ['url'],
        properties: { url: { type: 'string', format: 'uri' } }
      },
      response: {
        201: {
          type: 'object',
          required: ['code', 'shortUrl'],
          properties: {
            code: { type: 'string' },
            shortUrl: { type: 'string', format: 'uri' }
          }
        },
        400: {
          type: 'object',
          properties: { error: { type: 'string' } }
        }
      }
    }
  }, async (request, reply) => {
    const parse = shortenSchema.safeParse(request.body);
    if (!parse.success) {
      return reply.code(400).send({ error: 'Invalid URL' });
    }
    const { url: inputUrl } = parse.data;
    const { url: normalized, error } = normalizeUrl(inputUrl, {
      allowedHosts: ALLOWED_HOSTS,
      blockPrivateNetworks: BLOCK_PRIVATE_NETWORKS
    });
    if (error) {
      app.log.info({ reason: error }, `Shorten rejected: ${error}`);
      return reply.code(400).send({ error });
    }
    let code;
    do {
      code = nanoid(7);
    } while (store.has(code));
    const now = new Date().toISOString();
    store.set(code, { target_url: normalized, hits: 0, created_at: now });
    let baseUrl = env.BASE_URL ? env.BASE_URL.replace(/\/+$/, '') : undefined;
    if (!baseUrl && app.server && app.server.address && typeof app.server.address === 'function') {
      const addr = app.server.address();
      if (addr && addr.port) baseUrl = `http://localhost:${addr.port}`;
    }
    if (!baseUrl) baseUrl = 'http://localhost';
    const shortUrl = `${baseUrl}/${code}`;
    return reply.code(201).send({ code, shortUrl });
  });

  app.get('/:code', {
    schema: {
      params: {
        type: 'object',
        required: ['code'],
        properties: { code: { type: 'string' } }
      },
      response: {
        302: { type: 'null', description: 'Redirect to target_url' },
        404: { type: 'object', properties: { error: { type: 'string' } } }
      }
    }
  }, async (request, reply) => {
    return redirectByCode(reply, request.params.code, { store });
  });

  app.get('/stats/:code', {
    schema: {
      params: {
        type: 'object',
        required: ['code'],
        properties: { code: { type: 'string' } }
      },
      response: {
        200: {
          type: 'object',
          required: ['code', 'target_url', 'hits', 'created_at'],
          properties: {
            code: { type: 'string' },
            target_url: { type: 'string', format: 'uri' },
            hits: { type: 'integer' },
            created_at: { type: 'string' }
          }
        },
        404: { type: 'object', properties: { error: { type: 'string' } } }
      }
    }
  }, async (request, reply) => {
    const { code } = request.params;
    const entry = store.get(code);
    if (!entry) {
      return reply.code(404).send({ error: 'Not found' });
    }
    return reply.send({ code, ...entry });
  });

  // Diagnose-Route ganz unten
  app.get('/__ping', {
    schema: {
      summary: 'ping',
      response: {
        200: {
          type: 'object',
          properties: {
            pong: { type: 'boolean' }
          }
        }
      }
    }
  }, async () => ({ pong: true }));
};
