module.exports = {
  testEnvironment: 'node',
  testMatch: ['**/test/**/*.test.js'],
};
