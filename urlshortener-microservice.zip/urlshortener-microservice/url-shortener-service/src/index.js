
// All imports at the top, only once
const fastify = require('fastify');
// const { nanoid } = require('nanoid');
// const { z } = require('zod');
const net = require('net');
// const { redirectByCode } = require('./security/redirectByCode');
const routes = require('./routes');
const swagger = require('@fastify/swagger');
const swaggerUi = require('@fastify/swagger-ui');

const DANGEROUS_SCHEMES = ['javascript:', 'data:', 'vbscript:'];

function isPrivateIp(host) {
  if (net.isIP(host) === 4) {
    const parts = host.split('.').map(Number);
    if (parts[0] === 10) return true;
    if (parts[0] === 127) return true;
    if (parts[0] === 192 && parts[1] === 168) return true;
    if (parts[0] === 172 && parts[1] >= 16 && parts[1] <= 31) return true;
    return false;
  }
  if (net.isIP(host) === 6) {
    if (host === '::1' || host.startsWith('fd') || host.startsWith('fe80')) return true;
    return false;
  }
  return false;
}

function normalizeUrl(input, { allowedHosts, blockPrivateNetworks }) {
  let url;
  try {
    url = new URL(input);
  } catch {
    return { error: 'Invalid URL' };
  }
  const proto = url.protocol.toLowerCase();
  if (!['http:', 'https:'].includes(proto)) return { error: 'Invalid URL' };
  if (DANGEROUS_SCHEMES.includes(proto)) return { error: 'Invalid URL' };
  const host = url.hostname.toLowerCase();
  if (host === 'localhost') return { error: 'Domain not allowed' };
  if (blockPrivateNetworks && isPrivateIp(host)) return { error: 'Domain not allowed' };
  if (allowedHosts && !allowedHosts.includes(host)) return { error: 'Domain not allowed' };
  url.hash = '';
  url.protocol = proto;
  url.hostname = host;
  if ((url.protocol === 'http:' && url.port === '80') || (url.protocol === 'https:' && url.port === '443')) url.port = '';
  const normalized = url.toString();
  if (/\r|\n/.test(normalized)) return { error: 'Invalid URL' };
  return { url: normalized };
}

function buildServer(env = {}) {
  const isDev = env.NODE_ENV !== 'production';
  const app = fastify({
    logger: isDev
      ? {
          transport: {
            target: 'pino-pretty'
          }
        }
      : true
  });

  // 1) Register Swagger FIRST
  app.register(swagger, {
    openapi: {
      openapi: '3.0.0',
      info: {
        title: 'URL Shortener API',
        version: '1.0.0'
      }
    }
  });

  // 2) Register all routes as plugin (with Fastify-JSON-Schema)
  app.register(routes, { env });

  // 3) Register Swagger UI AFTER all routes
  app.register(swaggerUi, {
    routePrefix: '/docs'
  });

  return app;
}


module.exports = { buildServer };


if (require.main === module) {
  (async () => {
    process.on('unhandledRejection', (reason) => {
      console.error({ reason }, 'Unhandled Rejection');
      process.exit(1);
    });
    process.on('uncaughtException', (err) => {
      console.error({ err }, 'Uncaught Exception');
      process.exit(1);
    });
    let desiredPort = Number(process.env.PORT) || 3000;
    let port = desiredPort;
    let finalPort = null;
    const maxAttempts = (desiredPort === 0) ? 1 : 201;
    let attempts = 0;
  const app = buildServer(process.env);
  let started = false;
  while (attempts < maxAttempts && !started) {
    try {
      await app.ready();
  await app.listen({ port, host: '0.0.0.0' });
  finalPort = app.server.address().port;
  global.finalPort = finalPort;
  const finalBaseUrl = process.env.BASE_URL ? process.env.BASE_URL.replace(/\/+$|\/$/g, '') : `http://localhost:${finalPort}`;
  app.log.info(`Server listening on ${finalBaseUrl}`);
  app.log.info(`Swagger UI: ${finalBaseUrl}/docs`);
      console.log("SWAGGER_PATH_KEYS:", Object.keys(app.swagger().paths || {}).length);
      started = true;
    } catch (err) {
      if (err.code === 'EADDRINUSE' && desiredPort !== 0) {
        app.log.warn(`Port ${port} in use, trying ${port + 1}...`);
        port++;
        attempts++;
      } else {
        app.log.error(err);
        process.exit(1);
      }
    }
  }
  if (!started) {
    app.log.error(`No free port found in range ${desiredPort}..${desiredPort + maxAttempts - 1}. Exiting.`);
    process.exit(1);
  }
  })();
}
// --- CLI start logic (Fastify v5, Swagger Sichtbarkeit) ---




// const { redirectSafe } = require('./security/redirectSafe');





function isPrivateIp(hostname) {
    if (parts[0] === 10) return true;
    if (parts[0] === 127) return true;
    if (parts[0] === 192 && parts[1] === 168) return true;
    if (parts[0] === 172 && parts[1] >= 16 && parts[1] <= 31) return true;
    return false;
  }









function normalizeUrl(input, { allowedHosts, blockPrivateNetworks }) {
  let url;
  try {
    url = new URL(input);
  } catch {
    return { error: 'Invalid URL' };
  }
  const proto = url.protocol.toLowerCase();
  if (!['http:', 'https:'].includes(proto)) return { error: 'Invalid URL' };
  if (DANGEROUS_SCHEMES.includes(proto)) return { error: 'Invalid URL' };
  const hostname = url.hostname.toLowerCase();
  if (hostname === 'localhost') return { error: 'Domain not allowed' };
  if (blockPrivateNetworks && isPrivateIp(hostname)) return { error: 'Domain not allowed' };
  if (allowedHosts && !allowedHosts.includes(hostname)) return { error: 'Domain not allowed' };
  url.hash = '';
  url.protocol = proto;
  url.hostname = hostname;
  if ((url.protocol === 'http:' && url.port === '80') || (url.protocol === 'https:' && url.port === '443')) url.port = '';
  const normalized = url.toString();
  if (/\r|\n/.test(normalized)) return { error: 'Invalid URL' };
  return { url: normalized };


function buildServer(env = {}) {
  const isDev = env.NODE_ENV !== 'production';
  const app = fastify({
    logger: isDev
      ? {
          transport: {
            target: 'pino-pretty'
          }
        }
      : true
  });

  // Register Swagger FIRST
  app.register(swagger, {
    openapi: {
      openapi: '3.0.0',
      info: {
        title: 'URL Shortener API',
        version: '1.0.0'
      }
    }
  });

  // In-Memory Map für Shortlinks
  const store = new Map();

  // ENV-Konfiguration
  const ALLOWED_HOSTS = (env.ALLOWED_HOSTS)
    ? env.ALLOWED_HOSTS.split(',').map(h => h.trim().toLowerCase()).filter(Boolean)
    : null;
  const BLOCK_PRIVATE_NETWORKS = (typeof env.BLOCK_PRIVATE_NETWORKS !== 'undefined')
    ? env.BLOCK_PRIVATE_NETWORKS !== 'false'
    : true;

  // Zod-Schema für POST /shorten
  const shortenSchema = z.object({
    url: z.string().url()
  });

  // Routen mit Fastify-konformen Schemas
  app.post('/shorten', {
    schema: {
      body: {
        type: 'object',
        required: ['url'],
        properties: {
          url: { type: 'string', format: 'uri' }
        }
      },
      response: {
        201: {
          type: 'object',
          required: ['code', 'shortUrl'],
          properties: {
            code: { type: 'string' },
            shortUrl: { type: 'string', format: 'uri' }
          }
        },
        400: {
          type: 'object',
          properties: {
            error: { type: 'string' }
          }
        }
      }
    }
  }, async (request, reply) => {
    const parse = shortenSchema.safeParse(request.body);
    if (!parse.success) {
      return reply.code(400).send({ error: 'Invalid URL' });
    }
    const { url: inputUrl } = parse.data;
    const { url: normalized, error } = normalizeUrl(inputUrl, {
      allowedHosts: ALLOWED_HOSTS,
      blockPrivateNetworks: BLOCK_PRIVATE_NETWORKS
    });
    if (error) {
      app.log.info({ reason: error }, `Shorten rejected: ${error}`);
      return reply.code(400).send({ error });
    }
    let code;
    do {
      code = nanoid(7);
    } while (store.has(code));
    const now = new Date().toISOString();
    store.set(code, { target_url: normalized, hits: 0, created_at: now });
    const baseUrl = env.BASE_URL || "http://localhost";
    const shortUrl = `${baseUrl}/${code}`;
    return reply.code(201).send({ code, shortUrl });
  });

  app.get('/:code', {
    schema: {
      params: {
        type: 'object',
        required: ['code'],
        properties: {
          code: { type: 'string' }
        }
      },
      response: {
        302: {
          type: 'null',
          description: 'Redirect to target_url'
        },
        404: {
          type: 'object',
          properties: {
            error: { type: 'string' }
          }
        }
      }
    }
  }, async (request, reply) => {
    return redirectByCode(reply, request.params.code, { store });
  });

  app.get('/stats/:code', {
    schema: {
      params: {
        type: 'object',
        required: ['code'],
        properties: {
          code: { type: 'string' }
        }
      },
      response: {
        200: {
          type: 'object',
          required: ['code', 'target_url', 'hits', 'created_at'],
          properties: {
            code: { type: 'string' },
            target_url: { type: 'string', format: 'uri' },
            hits: { type: 'integer' },
            created_at: { type: 'string' }
          }
        },
        404: {
          type: 'object',
          properties: {
            error: { type: 'string' }
          }
        }
      }
    }
  }, async (request, reply) => {
    const { code } = request.params;
    const entry = store.get(code);
    if (!entry) {
      return reply.code(404).send({ error: 'Not found' });
    }
    return reply.send({ code, ...entry });
  });

  app.get('/healthz', {
    schema: {
      response: {
        200: {
          type: 'object',
          properties: {
            status: { type: 'string' }
          }
        }
      }
    }
  }, async () => {
    return { status: 'ok' };
  });

  app.get('/__ping', {
    schema: {
      summary: 'Diag ping',
      response: {
        200: {
          type: 'object',
          properties: {
            pong: { type: 'boolean' }
          }
        }
      }
    }
  }, async () => ({ pong: true }));

  // Register Swagger UI AFTER all routes
  app.register(swaggerUi, {
    routePrefix: '/docs'
  });

  app.store = store;
  return app;
}

module.exports = { buildServer };

if (require.main === module) {

  (async () => {
    process.on('unhandledRejection', (reason) => {
      // eslint-disable-next-line no-console
      console.error({ reason }, 'Unhandled Rejection');
      process.exit(1);
    });

    process.on('uncaughtException', (err) => {
      // eslint-disable-next-line no-console
      console.error({ err }, 'Uncaught Exception');
      process.exit(1);
    });

    let desiredPort = Number(process.env.PORT) || 3000;
    let port = desiredPort;
    let finalPort = null;
    const maxAttempts = (desiredPort === 0) ? 1 : 201;
    let attempts = 0;
    const app = buildServer(process.env);
    let started = false;
    while (attempts < maxAttempts && !started) {
      try {
  await app.ready();
  // Ausgabe der Swagger-Pfade direkt nach ready()
  console.log('SWAGGER_PATH_KEYS:', Object.keys(app.swagger().paths || {}).length);
        await app.listen({ port, host: '0.0.0.0' });
        finalPort = app.server.address().port;
        const finalBaseUrl = process.env.BASE_URL || `http://localhost:${finalPort}`;
        app.log.info(`Server listening on ${finalBaseUrl}`);
        app.log.info(`Swagger UI: ${finalBaseUrl}/docs`);
        console.log("SWAGGER_PATH_KEYS:", Object.keys(app.swagger().paths || {}).length);
        started = true;
      } catch (err) {
        if (err.code === 'EADDRINUSE' && desiredPort !== 0) {
          app.log.warn(`Port ${port} in use, trying ${port + 1}...`);
          port++;
          attempts++;
        } else {
          app.log.error(err);
          process.exit(1);
        }
      }
    }
    if (!started) {
      app.log.error(`No free port found in range ${desiredPort}..${desiredPort + maxAttempts - 1}. Exiting.`);
      process.exit(1);
    }
  })();
}

}