
/**
 * @jest-environment node
 *
 * eslint-env jest
 */

let app, request;
const { buildServer } = require('../src/index');
const supertest = require('supertest');

  describe('URL Shortener Security Integration', () => {
    describe('default config', () => {
      beforeEach(async () => {
        app = buildServer({ BASE_URL: 'http://localhost' });
        await app.ready();
        request = supertest(app.server);
      });
      afterEach(async () => {
        if (app) await app.close();
      });

      test('POST /shorten rejects dangerous schemes', async () => {
        const response = await request.post('/shorten').send({ url: 'javascript:alert(1)' });
        expect(response.status).toBe(400);
        expect(response.body.error).toMatch(/invalid/i);
      });

      test('POST /shorten rejects localhost', async () => {
        let response = await request.post('/shorten').send({ url: 'http://localhost:1234' });
        expect(response.status).toBe(400);
        expect(response.body.error).toMatch(/domain not allowed/i);
      });

      test('POST /shorten rejects private IPs if BLOCK_PRIVATE_NETWORKS', async () => {
        let response = await request.post('/shorten').send({ url: 'http://192.168.0.1' });
        expect(response.status).toBe(400);
        expect(response.body.error).toMatch(/domain not allowed/i);
      });

      test('POST /shorten allows public http/https URLs', async () => {
        let response = await request.post('/shorten').send({ url: 'https://example.com' });
        expect(response.status).toBe(201);
        expect(response.body.code).toBeDefined();
        expect(response.body.shortUrl).toMatch(/^http:\/\/localhost\//);
      });

      test('GET /:code only redirects to stored/validated URLs', async () => {
        let response = await request.post('/shorten').send({ url: 'https://example.com' });
        const code = response.body.code;
        const redirect = await request.get('/' + code).redirects(0);
        expect([302, 307]).toContain(redirect.status);
        expect(redirect.headers.location).toBe('https://example.com/');
      });

      test('GET /:code returns 404 for unknown code', async () => {
        let response = await request.get('/notfoundcode');
        expect(response.status).toBe(404);
        expect(response.body.error).toMatch(/not found/i);
      });

      test('GET /stats/:code returns stats for valid code', async () => {
        let response = await request.post('/shorten').send({ url: 'https://example.com' });
        const code = response.body.code;
        const stats = await request.get('/stats/' + code);
        expect(stats.status).toBe(200);
        expect(stats.body.code).toBe(code);
        expect(stats.body.target_url).toBe('https://example.com/');
        expect(typeof stats.body.hits).toBe('number');
        expect(stats.body.created_at).toBeDefined();
      });

      test('GET /healthz returns ok', async () => {
        let response = await request.get('/healthz');
        expect(response.status).toBe(200);
        expect(response.body.status).toBe('ok');
      });

      test('GET /:code uses redirectSafe and returns 302 Location with normalized URL', async () => {
        let response = await request.post('/shorten').send({ url: 'https://example.com/SomePath#fragment' });
        expect(response.status).toBe(201);
        const code = response.body.code;
        const getRes = await request.get('/' + code).redirects(0);
        expect([302, 307]).toContain(getRes.status);
        expect(getRes.headers.location).toBe('https://example.com/SomePath');
      });

      test('GET /:code ignores query param ?next=... and only redirects to stored URL', async () => {
        let response = await request.post('/shorten').send({ url: 'https://example.com/abc' });
        expect(response.status).toBe(201);
        const code = response.body.code;
        // Attempt to inject a different URL via ?next param
        const getRes = await request.get(`/${code}?next=https://evil.com`).redirects(0);
        expect([302, 307]).toContain(getRes.status);
        expect(getRes.headers.location).toBe('https://example.com/abc');
        // Attempt to inject via ?url param
        const getRes2 = await request.get(`/${code}?url=https://evil.com`).redirects(0);
        expect([302, 307]).toContain(getRes2.status);
        expect(getRes2.headers.location).toBe('https://example.com/abc');
        // Attempt to inject via POST body (should not be allowed, but test for future regressions)
        const postRes = await request.post(`/${code}`).send({ url: 'https://evil.com' });
        // Should not allow POST to /:code, expect 404 or method not allowed
        expect([404, 405]).toContain(postRes.status);
      });

      test('POST /shorten rejects dangerous schemes and CR/LF', async () => {
        for (const url of [
          'javascript:alert(1)',
          'data:text/html,hi',
          'file:///etc/passwd',
          'https://example.com/\r\nbad'
        ]) {
          let response = await request.post('/shorten').send({ url });
          expect(response.status).toBe(400);
          expect(response.body.error).toBeDefined();
        }
      });
    });

    describe('with BLOCK_PRIVATE_NETWORKS=true', () => {
      beforeEach(async () => {
        app = buildServer({ BASE_URL: 'http://localhost', BLOCK_PRIVATE_NETWORKS: 'true' });
        await app.ready();
        request = supertest(app.server);
      });
      afterEach(async () => {
        if (app) await app.close();
      });
      test('POST /shorten rejects localhost/private IPs', async () => {
        for (const url of [
          'http://localhost',
          'http://127.0.0.1',
          'http://192.168.0.10'
        ]) {
          let response = await request.post('/shorten').send({ url });
          expect(response.status).toBe(400);
          expect(response.body.error).toMatch(/domain not allowed/i);
        }
      });
    });

    describe('with ALLOWED_HOSTS=example.com', () => {
      beforeEach(async () => {
        app = buildServer({ BASE_URL: 'http://localhost', ALLOWED_HOSTS: 'example.com' });
        await app.ready();
        request = supertest(app.server);
      });
      afterEach(async () => {
        if (app) await app.close();
      });
      test('POST /shorten allows only ALLOWED_HOSTS', async () => {
        // allowed
        let response = await request.post('/shorten').send({ url: 'https://example.com/a' });
        expect(response.status).toBe(201);
        // not allowed
        response = await request.post('/shorten').send({ url: 'https://evil.com' });
        expect(response.status).toBe(400);
        expect(response.body.error).toMatch(/domain not allowed/i);
      });
    });
  });


