/**
 * Single redirect point – security enforced.
 * Only allows redirecting to a normalized, previously validated URL from the store.
 * Throws if the URL is not a string, not absolute http/https, or contains CR/LF.
 * Never use with raw input from request params/query/body!
 * @param {import('fastify').FastifyReply} reply
 * @param {string} normalizedUrl
 */
function redirectSafe(reply, normalizedUrl) {
  // Type and runtime guards
  if (typeof normalizedUrl !== 'string') {
    throw new Error('redirectSafe: URL must be a string');
  }
  if (!/^https?:\/\//.test(normalizedUrl)) {
    throw new Error('redirectSafe: Only absolute http/https URLs allowed');
  }
  if (/\r|\n/.test(normalizedUrl)) {
    throw new Error('redirectSafe: CR/LF detected in URL');
  }
  // No fragments (should be stripped by normalization)
  if (normalizedUrl.includes('#')) {
    throw new Error('redirectSafe: URL must not contain fragments');
  }
  // Only redirect to normalized, validated URLs from the store!
  return reply.redirect(302, normalizedUrl);
}

module.exports = { redirectSafe };
