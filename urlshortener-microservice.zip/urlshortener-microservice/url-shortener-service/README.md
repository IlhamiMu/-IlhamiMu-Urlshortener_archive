# url-shortener-service

## Run with Docker

**Build:**
```sh
docker build -t url-shortener .
```

**Run:**
```sh
docker run --rm -p 3000:3000 -e PORT=3000 -e BASE_URL=http://localhost:3000 url-shortener
```

**Compose:**
```sh
docker compose up --build
```

**Test:**
- Health: [http://localhost:3000/healthz](http://localhost:3000/healthz)
- Swagger UI: [http://localhost:3000/docs](http://localhost:3000/docs)

**Hinweis:**  
Redirect-Tests im Browser öffnen (Swagger folgt 302 nicht wegen CORS).